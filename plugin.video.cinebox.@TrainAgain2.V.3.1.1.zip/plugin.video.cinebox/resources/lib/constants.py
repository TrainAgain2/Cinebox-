# -*- coding: utf-8 -*-

import os
import xbmcaddon

# --- Configuração de Caminhos ---
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON_PATH = os.path.join(ADDON_PATH, 'resources', 'medias', 'icons')

MAIN_MENU = [
    {
        'title': 'Filmes',
        'action': 'movies_menu',
        'icon': 'pmyCOx7',
        'plot': 'Filmes do catálogo TMDB e listas públicas do Trakt.'
    },

    {
        'title': 'Séries',
        'action': 'tvshows_menu',
        'icon': 'R3NEEJl',
        'plot': 'Séries do TMDB e listas públicas do Trakt.'
    },
    {
        'title': 'Crunchyroll',
        'action': 'list_animes',
        'icon': os.path.join(ICON_PATH, 'crunchyroll_white.png'),
        'plot': 'Animes e conteúdos da Crunchyroll via TMDB.'
    },

    {
        'title': 'Coleções',
        'action': 'list_collections',
        'icon': '2OJn9MC',
        'plot': 'Sagas e franquias completas de filmes.'
    },
    {
        'title': 'Pesquisar',
        'action': 'search',
        'icon': 'owsADQ4',
        'plot': 'Pesquisar filmes e séries por título.'
    },
    {
        'title': 'Minha Lista',
        'action': 'favorites_menu',
        'icon': 'XbEEv9X',
        'plot': 'Seus favoritos e itens salvos localmente.'
    },
    {
        'title': 'Trakt',
        'action': 'trakt_main_menu',
        'icon': os.path.join(ICON_PATH, 'trakt_red.png'),
        'plot': 'Watchlist, coleção, assistidos e sincronização com sua conta Trakt.'
    },

    {
        'title': '[COLOR red]Configurações[/COLOR]',
        'action': 'open_settings',
        'icon': os.path.join(ICON_PATH, 'settings_red.png'),
        'plot': 'Configurações, manutenção e informações do addon.'
    },
]


TOOLS_MENU = [
    {'title': 'Configurações', 'action': 'open_settings', 'icon': os.path.join(ICON_PATH, 'settings_red.png')},
    {'title': '[COLOR gold]Atualizar Catálogo[/COLOR]', 'action': 'update_catalog', 'icon': 'vBwrjLV'},
    {'title': 'Changelog', 'action': 'show_changelog', 'icon': 'XbEEv9X'},
    {'title': 'Doação', 'action': 'show_donation', 'icon': 'XbEEv9X'}
]

MOVIES_MENU = [
    {'title': 'Streaming', 'action': 'list_streaming_platforms_movies', 'icon': os.path.join(ICON_PATH, 'tmdb_color.png')},
    {'title': 'Tendências', 'action': 'list_trending_movies', 'icon': 'rVq7so0'},
    {'title': 'Populares', 'action': 'list_movies_by_popularity', 'icon': 'ngkznpf'},
    {'title': 'Melhor Avaliados', 'action': 'list_movies_top_rated', 'icon': 'aj02pjQ'},
    {'title': 'Nos Cinemas', 'action': 'list_movies_now_playing', 'icon': '9660DAY'},
    {'title': 'Próximos Filmes', 'action': 'list_upcoming_movies', 'icon': 's4krx5q'},
    {'title': 'Gêneros', 'action': 'list_genres', 'icon': '6QpJbS0'},
    {'title': 'Maiores bilheterias', 'action': 'list_movies_by_revenue', 'icon': 'WzYp4H8'},
    {'title': 'Por Ano', 'action': 'list_years', 'icon': 'fN4GQmO'},  # Ícone de calendário do IMDb

    {'title': 'Tendências (Trakt)', 'action': 'trakt_movies_trending', 'icon': os.path.join(ICON_PATH, 'trakt_red.png')},
    {'title': 'Populares', 'action': 'trakt_movies_popular', 'icon': os.path.join(ICON_PATH, 'trakt_red.png')},
    {'title': 'Mais Assistidos', 'action': 'trakt_movies_most_watched', 'icon': os.path.join(ICON_PATH, 'trakt_red.png')},
    {'title': 'Mais Coletados', 'action': 'trakt_movies_most_collected', 'icon': os.path.join(ICON_PATH, 'trakt_red.png')},
    {'title': 'Mais Aguardados', 'action': 'trakt_movies_most_anticipated', 'icon': os.path.join(ICON_PATH, 'trakt_red.png')},
    {'title': 'Bilheteria', 'action': 'trakt_movies_box_office', 'icon': os.path.join(ICON_PATH, 'trakt_red.png')},
    {'title': 'Melhor Avaliados', 'action': 'trakt_movies_top_rated', 'icon': os.path.join(ICON_PATH, 'trakt_red.png')},
]

TVSHOWS_MENU = [
    {'title': 'Streaming', 'action': 'list_streaming_platforms_tvshows', 'icon': os.path.join(ICON_PATH, 'tmdb_color.png')},
    {'title': 'Tendências', 'action': 'list_trending_tvshows', 'icon': 'rVq7so0'},
    {'title': 'Populares', 'action': 'list_tvshows_by_popularity', 'icon': 'ngkznpf'},
    {'title': 'Melhor Avaliadas', 'action': 'list_tvshows_top_rated', 'icon': 'aj02pjQ'},
    {'title': 'Passam Hoje', 'action': 'list_tvshows_airing_today', 'icon': 'fN4GQmO'},
    {'title': 'No Ar (Semana)', 'action': 'list_tvshows_on_the_air', 'icon': 'Ht6HpQO'},
    {'title': 'Próximas Séries', 'action': 'list_upcoming_tvshows', 'icon': 's4krx5q'},
    {'title': 'Gêneros', 'action': 'list_tvshows_genres', 'icon': '6QpJbS0'},
    {'title': 'Por Ano', 'action': 'list_tvshows_years', 'icon': 'fN4GQmO'},  # Ícone de calendário do IMDb
    {'title': 'Infantil', 'action': 'list_kids_tvshows', 'icon': 'cMjxdqe'},
    {'title': 'Tendências (Trakt)', 'action': 'trakt_tv_trending', 'icon': os.path.join(ICON_PATH, 'trakt_red.png')},
    {'title': 'Populares', 'action': 'trakt_tv_popular', 'icon': os.path.join(ICON_PATH, 'trakt_red.png')},
    {'title': 'Mais Assistidas', 'action': 'trakt_tv_most_watched', 'icon': os.path.join(ICON_PATH, 'trakt_red.png')},
    {'title': 'Mais Coletadas', 'action': 'trakt_tv_most_collected', 'icon': os.path.join(ICON_PATH, 'trakt_red.png')},
    {'title': 'Mais Aguardadas', 'action': 'trakt_tv_most_anticipated', 'icon': os.path.join(ICON_PATH, 'trakt_red.png')},
    {'title': 'Melhor Avaliadas', 'action': 'trakt_tv_top_rated', 'icon': os.path.join(ICON_PATH, 'trakt_red.png')},
    {'title': 'Recomendadas', 'action': 'trakt_tv_recommended', 'icon': os.path.join(ICON_PATH, 'trakt_red.png')},
]

# === ✅ MENU TRAKT CORRIGIDO ===
TRAKT_MENU = [
    {'title': 'Status / Autenticar', 'action': 'trakt_auth', 'icon': os.path.join(ICON_PATH, 'trakt_red.png')},
    {'title': 'Watchlist', 'action': 'trakt_watchlist_menu', 'icon': os.path.join(ICON_PATH, 'trakt_red.png')},
    {'title': 'Coleção', 'action': 'trakt_collection_menu', 'icon': os.path.join(ICON_PATH, 'trakt_red.png')},
    {'title': 'Assistidos', 'action': 'trakt_watched_menu', 'icon': os.path.join(ICON_PATH, 'trakt_red.png')},
    {'title': 'Minhas Listas', 'action': 'trakt_lists_menu', 'icon': os.path.join(ICON_PATH, 'trakt_red.png')},
]

STREAMING_MENU = [
    {'title': 'Streaming', 'action': 'list_streaming_platforms_movies', 'icon': os.path.join(ICON_PATH, 'tmdb_color.png')},
    {'title': 'Streaming', 'action': 'list_streaming_platforms_tvshows', 'icon': os.path.join(ICON_PATH, 'tmdb_color.png')},
]

LOGO_PATH = os.path.join(ADDON_PATH, 'resources', 'logos')

# ✅ IDs COMBINADOS PARA CONTEÚDO COMPLETO (BR)
# Inclui canais extras e variantes para garantir catálogo máximo
NETFLIX_IDS = "8|1796"
PRIME_IDS = "119|2100"
DISNEY_IDS = "337"
MAX_IDS = "1899|1825|2472"
PARAMOUNT_IDS = "531|1853|2303"
GLOBOPLAY_IDS = "307"
APPLE_IDS = "2|350|2243"
CLARO_IDS = "484"
CRUNCHY_IDS = "283|1968"
MERCADO_IDS = "2302"
TELECINE_IDS = "2156"

STREAMING_PLATFORMS = {
    'movie': [
        {'name': 'Netflix', 'id': NETFLIX_IDS, 'logo': 'pbpMk2JmcoNnQwx5JGpXngfoWtp.jpg', 'region': 'BR'},
        {'name': 'Amazon Prime Video', 'id': PRIME_IDS, 'logo': 'pvske1MyAoymrs5bguRfVqYiM9a.jpg', 'region': 'BR'},
        {'name': 'Disney Plus', 'id': DISNEY_IDS, 'logo': '97yvRBw1GzX7fXprcF80er19ot.jpg', 'region': 'BR'},
        {'name': 'Max', 'id': MAX_IDS, 'logo': 'jbe4gVSfRlbPTdESXhEKpornsfu.jpg', 'region': 'BR'},
        {'name': 'Globoplay', 'id': GLOBOPLAY_IDS, 'logo': '7Cg8esVVXOijXAm1f1vrS7jVjcN.jpg', 'region': 'BR'},
        {'name': 'Paramount Plus', 'id': PARAMOUNT_IDS, 'logo': 'h5DcR0J2EESLitnhR8xLG1QymTE.jpg', 'region': 'BR'},
        {'name': 'Apple TV', 'id': APPLE_IDS, 'logo': 'mcbz1LgtErU9p4UdbZ0rG6RTWHX.jpg', 'region': 'BR'},
        {'name': 'Claro TV+', 'id': CLARO_IDS, 'logo': '7EpFKOCMrlo3bjsyBMrec64c7Wb.jpg', 'region': 'BR'},
        {'name': 'Telecine', 'id': TELECINE_IDS, 'logo': '9kcTsX2laYclN4bFiMH3RuhZel2.jpg', 'region': 'BR'},
        {'name': 'Crunchyroll', 'id': CRUNCHY_IDS, 'logo': 'fzN5Jok5Ig1eJ7gyNGoMhnLSCfh.jpg', 'region': 'BR'},
        {'name': 'Mercado Play', 'id': MERCADO_IDS, 'logo': '60iyHW9xKBKVBf0kxiQixuLqG1f.jpg', 'region': 'BR'},
        {'name': 'MUBI', 'id': 11, 'logo': 'x570VpH2C9EKDf1riP83rYc5dnL.jpg', 'region': 'BR'},
    ],
    'tv': [
        {'name': 'Netflix', 'id': NETFLIX_IDS, 'logo': 'pbpMk2JmcoNnQwx5JGpXngfoWtp.jpg', 'region': 'BR'},
        {'name': 'Amazon Prime Video', 'id': PRIME_IDS, 'logo': 'pvske1MyAoymrs5bguRfVqYiM9a.jpg', 'region': 'BR'},
        {'name': 'Disney Plus', 'id': DISNEY_IDS, 'logo': '97yvRBw1GzX7fXprcF80er19ot.jpg', 'region': 'BR'},
        {'name': 'Max', 'id': MAX_IDS, 'logo': 'jbe4gVSfRlbPTdESXhEKpornsfu.jpg', 'region': 'BR'},
        {'name': 'Globoplay', 'id': GLOBOPLAY_IDS, 'logo': '7Cg8esVVXOijXAm1f1vrS7jVjcN.jpg', 'region': 'BR'},
        {'name': 'Paramount Plus', 'id': PARAMOUNT_IDS, 'logo': 'h5DcR0J2EESLitnhR8xLG1QymTE.jpg', 'region': 'BR'},
        {'name': 'Apple TV', 'id': APPLE_IDS, 'logo': 'mcbz1LgtErU9p4UdbZ0rG6RTWHX.jpg', 'region': 'BR'},
        {'name': 'Claro TV+', 'id': CLARO_IDS, 'logo': '7EpFKOCMrlo3bjsyBMrec64c7Wb.jpg', 'region': 'BR'},
        {'name': 'Crunchyroll', 'id': CRUNCHY_IDS, 'logo': 'fzN5Jok5Ig1eJ7gyNGoMhnLSCfh.jpg', 'region': 'BR'},
        {'name': 'Mercado Play', 'id': MERCADO_IDS, 'logo': '60iyHW9xKBKVBf0kxiQixuLqG1f.jpg', 'region': 'BR'},
        {'name': 'MUBI', 'id': 11, 'logo': 'x570VpH2C9EKDf1riP83rYc5dnL.jpg', 'region': 'BR'},
    ]
}
