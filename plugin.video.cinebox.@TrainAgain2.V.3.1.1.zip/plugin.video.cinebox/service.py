# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import sys
import os
import threading

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
sys.path.append(os.path.join(ADDON_PATH, 'resources', 'lib'))

def run_trakt_service(monitor):
    """Executa sincronização automática do Trakt em uma thread"""
    def _sync():
        try:
            # Aguarda um pouco para não sobrecarregar o início
            if monitor.waitForAbort(15): return
            
            from resources.lib.trakt_sync import full_bidirectional_sync, get_trakt_settings
            
            settings = get_trakt_settings()
            if not settings.get('access_token'):
                return
            
            xbmc.log("[Cinebox Trakt Service] Iniciando sincronização de inicialização...", xbmc.LOGINFO)
            full_bidirectional_sync()
                
        except Exception as e:
            xbmc.log(f"[Cinebox Trakt Service] Erro: {e}", xbmc.LOGERROR)

    threading.Thread(target=_sync, name="TraktSyncThread").start()

class CineboxService(xbmc.Monitor):
    def __init__(self):
        xbmc.Monitor.__init__(self)
        xbmc.log("[Cinebox Service] Inicializando...", xbmc.LOGINFO)
        
        # Inicia o AutoUpdater (agora baseado no sistema do IMDB)
        try:
            from resources.lib.auto_updater import AutoUpdater
            self.updater = AutoUpdater(self)
            self.updater.start()
        except Exception as e:
            xbmc.log(f"[Cinebox Service] Erro ao iniciar AutoUpdater: {e}", xbmc.LOGERROR)
        
        # Inicia o Trakt Sync (em thread separada)
        if ADDON.getSettingBool('trakt_sync_on_startup'):
            run_trakt_service(self)

    def onSettingsChanged(self):
        # O AutoUpdater agora verifica as configurações dentro do seu próprio loop
        # mas poderíamos forçar uma atualização de estado aqui se necessário
        pass

if __name__ == '__main__':
    service = CineboxService()
    # Mantém o serviço rodando até o Kodi fechar
    service.waitForAbort()
    xbmc.log("[Cinebox Service] Finalizado", xbmc.LOGINFO)
